package com.example.myapplication.utils

object Constants {
    const val SEND_ID = "SEND_ID"
    const val RECEIVE_ID = "RECEIVE_ID"
    const val OPEN_BOOKING = "Открываю Booking.. "
    const val OPEN_SEARCH = "Поиск.. "
    var i = 0
    var arr: Array<String> = arrayOf("1", "1", "1", "1", "1", "1")
}