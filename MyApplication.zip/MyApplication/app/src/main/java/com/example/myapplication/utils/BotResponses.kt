package com.example.myapplication.utils


import android.provider.Settings
import kotlinx.android.synthetic.main.activity_fullscreen.*
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.data.Message
import com.example.myapplication.ui.MessagingAdapter
import com.example.myapplication.utils.Constants.OPEN_BOOKING
import com.example.myapplication.utils.Constants.OPEN_SEARCH
import com.example.myapplication.utils.Constants.arr
import com.example.myapplication.utils.Constants.i
import kotlinx.coroutines.*
import java.util.*


object BotResponse {
    fun basicResponses(_message: String): String {

        val random = (0..2).random()
        val message = _message.lowercase(Locale.getDefault())

        when {

            message.contains("привет") -> {
                return when (random) {
                    0 -> "Привет!"
                    1 -> "Здравствуйте!"
                    2 -> "Рад вас видеть!"
                    else -> "error"
                }
            }


            message.contains("открой") && message.contains("booking") -> {
                return OPEN_BOOKING
            }

            //Search on the internet
            message.contains("найди") -> {
                return OPEN_SEARCH
            }


            else -> {

                arr[i] = message
                if (i == 0) {
                    i += 1
                    arr[i] = message
                    return "Куда вы хотите отправиться?"
                } else if (i == 1) {
                    i += 1
                    arr[i] = message
                    return "Каков ваш бюджет?"
                } else if (i == 2) {
                    i += 1
                    arr[i] = message
                    return "Когда планируете отправиться?"
                } else if (i == 3) {
                    i += 1
                    arr[i] = message
                    return "Сколько взрослых?"
                } else if (i == 4) {
                    i += 1
                    arr[i] = message
                    return "Сколько детей?"
                } else if (i == 5)
                {
                    var a = ""
                    for (index in arr) {
                        a += index
                    }
                    val v = arr
                    i = 0
                    arr  = arrayOf("1", "1", "1", "1", "1", "1")
                    return "Откуда: ${v[0]}\nКуда: ${v[1]}\nБюджет: ${v[2]}\nДата: ${v[3]}\nКоличество взрослых: ${v[4]}\nКоличество детей: ${v[5]}\n"
             } else return "Я Вас не понял"


            }

        }

    }
}



